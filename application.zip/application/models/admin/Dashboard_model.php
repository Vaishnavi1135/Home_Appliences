<?php

class Dashboard_model extends CI_Model{

    private $table = "User";
    public function read(){
        
    }
}
?>