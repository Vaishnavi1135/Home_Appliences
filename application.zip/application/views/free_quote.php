<div class="container">
        <div class="container">
            <div class="row g-6">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
               <!-- <h3 class="text-black text-uppercase mt-3" style="text-italic">Free Quote...!!</h3> -->
                    
                <img class="img-fluid mb-8" src="<?php echo base_url();?>\assets\images\food-delivery.png" alt="">
                        
                
                    
                </div>
                <div class="col-lg-6 mt-5">
                <h3 class="text-danger text-uppercase mt-3" style="text-italic"> Get A Free Quote...!!</h3>
                    <div class="bg-light text-center p-5 wow fadeIn mt-5 pt-5" data-wow-delay="0.5s">
                   
                        <form>
                            <div class="row g-3">
                                <div class="col-12 col-sm-6 ">
                                    <input type="text" class="form-control border-0" placeholder="Email" style="height: 55px;">
                                </div>
                                <div class="col-12 col-sm-6">
                                    <input type="email" class="form-control border-0" placeholder="Phone No" style="height: 55px;">
                                </div>
                                <div class="col-12 col-sm-12">
                                    <input type="text" class="form-control border-0" placeholder="Location From" style="height: 55px;">
                                </div>

                                <div class="col-12 col-sm-12">
                                    <input type="text" class="form-control border-0" placeholder="Location To" style="height: 55px;">
                                </div>
                                
                                <div class="col-12">
                                    <textarea class="form-control border-0" placeholder="Special Note"></textarea>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary w-100 py-3" type="submit">Send Request</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    